package com.lubnamariyam.soho.model.weather

data class Sys(
    val country: String,
    val sunrise: Int,
    val sunset: Int
)