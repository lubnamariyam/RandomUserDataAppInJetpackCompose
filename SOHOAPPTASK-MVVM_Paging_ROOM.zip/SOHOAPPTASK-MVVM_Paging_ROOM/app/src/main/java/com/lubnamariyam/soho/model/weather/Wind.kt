package com.lubnamariyam.soho.model.weather

data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)