package com.lubnamariyam.soho.model.weather

data class Clouds(
    val all: Int
)